This is A.

This is B.
